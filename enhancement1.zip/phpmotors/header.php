<!-- Header -->
<a href="/template.php" title="Go to the phpmotors.com home page">
<img src="images/site/logo.png" alt="php motors logo">
</a>
<div id="my-account"> My Account </div>

<!-- Footer -->
<p>PHP Motors. All rights reserved</p>
<p class="sub-footer">All images used are believed to be in Fair Use. Please notify if any are not and they will be removed</p>
<!-- last modified -->
<p id="last-modified"><span>Last modified : April 25 2023</span></p>